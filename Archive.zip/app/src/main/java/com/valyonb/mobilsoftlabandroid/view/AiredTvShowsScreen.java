package com.valyonb.mobilsoftlabandroid.view;

import com.valyonb.mobilsoftlabandroid.model.Movie;

import java.util.List;

/**
 * Created by valyonbalazs on 21/04/16.
 */
public interface AiredTvShowsScreen {

    public void showMovies(List<Movie> movieList);
}
