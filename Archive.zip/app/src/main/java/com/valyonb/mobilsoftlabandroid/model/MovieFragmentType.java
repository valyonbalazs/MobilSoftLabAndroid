package com.valyonb.mobilsoftlabandroid.model;

/**
 * Created by valyonbalazs on 21/04/16.
 */
public enum MovieFragmentType {

    HOME,
    TOPMOVIES,
    NEWMOVIES,
    AIREDTVSHOW,
    FAVOURITE
}
