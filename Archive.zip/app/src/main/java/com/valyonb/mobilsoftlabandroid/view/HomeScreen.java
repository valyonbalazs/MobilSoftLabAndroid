package com.valyonb.mobilsoftlabandroid.view;

import com.valyonb.mobilsoftlabandroid.model.Movie;

import java.util.List;

/**
 * Created by valyonbalazs on 20/04/16.
 */
public interface HomeScreen {

    public void showMovies(List<Movie> movieList);
}
