package com.valyonb.mobilsoftlabandroid.networking;

/**
 * Created by valyonbalazs on 21/04/16.
 */
public interface Network {

    public void downloadData(String url);
}
